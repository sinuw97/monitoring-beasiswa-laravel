<!-- Modal -->
<div x-show="<?php echo e($show); ?>" x-cloak
    class="fixed inset-0 bg-[#f5f5f566] bg-opacity-50 flex items-center justify-center z-50" x-transition
    @click.away="<?php echo e($show); ?> = false">

    <div class="bg-white p-4 rounded-lg shadow-lg w-[400px]" @click.stop>
        <?php if($title): ?>
            <h2 class="text-lg font-bold mb-4"><?php echo e($title); ?></h2>
        <?php endif; ?>
        
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH G:\Code\Web\monitoring-beasiswa-laravel\resources\views\components\modal.blade.php ENDPATH**/ ?>