<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <title>Login Admin</title>
</head>
<body class="min-h-screen flex flex-col lg:flex-row">
    <!-- Bagian kiri (gradient background) -->
    <div class="hidden lg:flex lg:w-1/2 bg-gradient-to-t from-[#09697E] to-white"></div>

    <!-- Bagian kanan (form login) -->
    <div class="w-full lg:w-1/2 flex items-center justify-center p-4">
        <div class="w-full max-w-md bg-white p-6 sm:p-8 ">
            <!-- Logo -->
            <div class="flex flex-col items-center mb-6">
                <img src="<?php echo e(asset('icon/logo.svg')); ?>" alt="Logo TSU" class="h-30 mb-2">
            </div>

            <!-- Error -->
            <?php if($errors->any()): ?>
                <div class="text-red-500 mb-4 text-sm">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Form -->
            <form method="POST" action="<?php echo e(url('admin/login')); ?>" class="space-y-4">
                <?php echo csrf_field(); ?>
                <div>
                    <label class="block text-sm font-semibold text-gray-700">Email</label>
                    <input type="text" name="email" placeholder="Masukan email anda"
                        class="w-full mt-1 p-2 border rounded-md focus:ring-2 focus:ring-teal-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700">Password</label>
                    <input type="password" name="password" placeholder="Masukkan password anda"
                        class="w-full mt-1 p-2 border rounded-md focus:ring-2 focus:ring-teal-500 focus:outline-none">
                </div>

                <!-- Tombol Login Admin -->
                <div class="flex justify-between items-center text-sm">
                    <a href="<?php echo e(url('mahasiswa/login')); ?>" class="text-gray-500 hover:text-[#176578]">Login Sebagai Mahasiswa</a>
                </div>

                <!-- Tombol Login -->
                <button type="submit"
                    class="w-full bg-[#1D7D94] text-white py-2 rounded-md hover:bg-[#176578] transition">Login</button>
            </form>
        </div>
    </div>
</body>

</html>
<?php /**PATH G:\Code\Web\monitoring-beasiswa-laravel\resources\views\admin\login.blade.php ENDPATH**/ ?>