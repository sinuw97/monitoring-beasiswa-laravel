<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
  <title>Dashboard Admin</title>
</head>
<body>
  <?php echo $__env->make('components.navbar-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH G:\Code\Web\monitoring-beasiswa-laravel\resources\views/admin/layout.blade.php ENDPATH**/ ?>