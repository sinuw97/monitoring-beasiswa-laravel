<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="//unpkg.com/alpinejs" defer></script>
    <title>Pengisian Monev</title>
</head>

<body class="bg-[#F8F6F6]">
    <?php if (isset($component)) { $__componentOriginalab674573b0fa75d45d8b33fa67b4512e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab674573b0fa75d45d8b33fa67b4512e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar-mhs','data' => ['mhsAvatar' => ''.e($dataMahasiswa->avatar).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar-mhs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['mhsAvatar' => ''.e($dataMahasiswa->avatar).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab674573b0fa75d45d8b33fa67b4512e)): ?>
<?php $attributes = $__attributesOriginalab674573b0fa75d45d8b33fa67b4512e; ?>
<?php unset($__attributesOriginalab674573b0fa75d45d8b33fa67b4512e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab674573b0fa75d45d8b33fa67b4512e)): ?>
<?php $component = $__componentOriginalab674573b0fa75d45d8b33fa67b4512e; ?>
<?php unset($__componentOriginalab674573b0fa75d45d8b33fa67b4512e); ?>
<?php endif; ?>

    <section class="flex justify-center w-full h-auto">
        <div class="bg-[#fdfdfd] w-[1000px] h-auto p-6">
            <h2 class="text-xl font-bold ml-3.5 mb-2">Pengisian Laporan Monev</h2>

            <?php if($periodeAktif): ?>
                <div class="w-auto h-[50px] bg-blue-200 ml-3.5 mb-2 px-3 py-3">
                    <p>
                        Periode <?php echo e($periodeAktif->tahun_akademik); ?> <?php echo e($periodeAktif->semester); ?> Telah Dibuka
                    </p>
                </div>
            <?php endif; ?>

            <div class="overflow-x-auto mt-4">
                <table class="min-w-full text-sm shadow-lg bg-white border-separate border-spacing-0 m-4">
                    <thead>
                        <tr class="bg-[#E8BE00]">
                            <th class="px-4 py-2 text-center">No</th>
                            <th class="px-4 py-2 text-center">Semester</th>
                            <th class="px-4 py-2 text-center">Periode</th>
                            <th class="px-4 py-2 text-center">Status</th>
                            <th class="px-4 py-2 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="bg-[#f8f8f8]">
                                <td class="px-4 py-2 text-center"><?php echo e($row['no']); ?></td>
                                <td class="px-4 py-2 text-center"><?php echo e($row['semester']); ?></td>
                                <td class="px-4 py-2 text-center"><?php echo e($row['periode']); ?></td>
                                <td class="px-4 py-2 text-center"><?php echo e($row['status']); ?></td>
                                <td class="px-4 py-2 text-center">
                                    <?php if($row['status'] !== 'Dibuka'): ?>
                                        <button type="button"
                                            class="px-2 py-1 bg-[#d82222] text-[#f1f1f1] font-bold rounded cursor-default">Tutup</button>
                                    <?php else: ?>
                                        <?php if($row['aksi'] === 'Buat'): ?>
                                            <form action="<?php echo e(route('mahasiswa.buat-laporan', ['semesterId' => $row['semester_id'], 'semesterSekarang' => $row['semester']])); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="px-2 py-1 bg-[#09697E] text-white font-bold rounded cursor-pointer">
                                                    Buat
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('mahasiswa.lihat-laporan', $row['laporan_id'])); ?>"
                                                class="px-2 py-1 bg-[#1abc50] text-white font-bold rounded cursor-pointer">
                                                Lihat
                                            </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="<?php echo e(count($timrline)); ?>" class="px-4 py-4 text-center ">
                                    Tidak ada data
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</body>

</html>
<?php /**PATH G:\Code\Web\monitoring-beasiswa-laravel\resources\views\mahasiswa\halaman-pengisian-laporan.blade.php ENDPATH**/ ?>