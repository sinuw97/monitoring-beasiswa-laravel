<div class="bg-white w-full max-w-5xl mx-auto shadow-lg rounded-xl p-2 sm:p-6 border-l-4 border-[#09697E] my-6 sm:my-8">

    
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4">
        <h2 class="text-lg sm:text-xl font-semibold text-[#09697E]">Data Laporan Mahasiswa</h2>
        <div class="text-sm text-gray-600 mt-2 sm:mt-0">
            <span class="font-medium">Periode Aktif:</span>
            <?php echo e($periode->tahun_akademik); ?> - <?php echo e($periode->semester); ?>

        </div>
    </div>

    
    <form method="GET" action="<?php echo e(url('/admin/laporan')); ?>" class="grid grid-cols-1 sm:grid-cols-5 gap-2 sm:gap-3 mb-4 text-sm">
        
        <select name="angkatan" class="w-full border-gray-300 px-2 py-2 rounded-lg shadow-sm focus:border-[#09697E] focus:ring-[#09697E] cursor-pointer text-sm">
            <option value="">Semua Angkatan</option>
            <?php $__currentLoopData = $daftarAngkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($a->angkatan); ?>" <?php echo e(request('angkatan') == $a->angkatan ? 'selected' : ''); ?>>
                    20<?php echo e($a->angkatan); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        
        <select name="status" class="w-full border-gray-300 px-2 py-2 rounded-lg shadow-sm focus:border-[#09697E] focus:ring-[#09697E] cursor-pointer text-sm">
            <option value="">Semua Status</option>
            <option value="Pending" <?php echo e(request('status') == 'Pending' ? 'selected' : ''); ?>>Pending</option>
            <option value="Lolos" <?php echo e(request('status') == 'Lolos' ? 'selected' : ''); ?>>Lolos</option>
            <option value="Draft" <?php echo e(request('status') == 'Draft' ? 'selected' : ''); ?>>Draft</option>
            <option value="Ditolak SP-1" <?php echo e(request('status') == 'Ditolak SP-1' ? 'selected' : ''); ?>>Ditolak SP-1</option>
            <option value="Ditolak SP-2" <?php echo e(request('status') == 'Ditolak SP-2' ? 'selected' : ''); ?>>Ditolak SP-2</option>
            <option value="Ditolak SP-3" <?php echo e(request('status') == 'Ditolak SP-3' ? 'selected' : ''); ?>>Ditolak SP-3</option>
            <option value="Lolos dengan penugasan" <?php echo e(request('status') == 'Lolos dengan penugasan' ? 'selected' : ''); ?>>Lolos dengan penugasan</option>
        </select>

        
        <select name="periode" class="w-full border-gray-300 px-2 py-2 rounded-lg shadow-sm focus:border-[#09697E] focus:ring-[#09697E] cursor-pointer text-sm">
            <option value="">Periode Aktif (<?php echo e($periode->tahun_akademik); ?> - <?php echo e($periode->semester); ?>)</option>
            <?php $__currentLoopData = $daftarPeriode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $tahun = substr($p->tahun_akademik, 0, 4);
                    $kode = $p->semester == 'Ganjil' ? '01' : '02';
                    $periodeId = 'SM' . $tahun . $kode;
                ?>
                <option value="<?php echo e($periodeId); ?>" <?php echo e(request('periode') == $periodeId ? 'selected' : ''); ?>>
                    <?php echo e($p->tahun_akademik); ?> - <?php echo e($p->semester); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        
        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari NIM atau Nama..."
               class="w-full border-gray-300 p-2 rounded-lg shadow-sm focus:border-[#09697E] focus:ring-[#09697E] text-sm">

        
        <div class="flex gap-2">
            <button type="submit"
                    class="bg-[#09697E] hover:bg-[#075263] text-white rounded-lg px-4 py-2 w-full">
                Filter
            </button>
            <a href="<?php echo e(url('/admin/laporan')); ?>"
               class="bg-gray-400 hover:bg-gray-500 text-white rounded-lg px-4 py-2 w-full text-center">
                Reset
            </a>
        </div>
    </form>

    
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-xs sm:text-sm">
            <thead class="bg-[#09697E] text-white">
                <tr>
                    <th class="px-3 sm:px-6 py-3 text-left font-semibold uppercase tracking-wider">No</th>
                    <th class="px-3 sm:px-6 py-3 text-left font-semibold uppercase tracking-wider">NIM</th>
                    <th class="px-3 sm:px-6 py-3 text-left font-semibold uppercase tracking-wider">Nama</th>
                    <th class="px-3 sm:px-6 py-3 text-left font-semibold uppercase tracking-wider">Semester</th>
                    <th class="px-3 sm:px-6 py-3 text-left font-semibold uppercase tracking-wider">Status</th>
                    <th class="px-8 sm:px-16 py-3 text-center font-semibold uppercase tracking-wider whitespace-nowrap">Aksi</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $dataLaporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $status = $laporan->status;
                        $colorClass = '';

                        if (in_array($status, ['Lolos', 'Lolos dengan penugasan'])) {
                            $colorClass = 'bg-green-100 text-green-800';
                        } elseif ($status === 'Pending') {
                            $colorClass = 'bg-gray-200 text-gray-800';
                        } elseif ($status === 'Draft') {
                            $colorClass = 'bg-yellow-100 text-yellow-800';
                        } elseif (Str::contains($status, 'Ditolak')) {
                            $colorClass = 'bg-red-100 text-red-700';
                        } else {
                            $colorClass = 'bg-gray-100 text-gray-700';
                        }
                    ?>

                    <tr class="hover:bg-[#f7f7f7] transition">
                        <td class="px-3 sm:px-6 py-3 text-gray-800">
                            <?php echo e(($dataLaporan->currentPage() - 1) * $dataLaporan->perPage() + $loop->iteration); ?>

                        </td>
                        <td class="px-3 sm:px-6 py-3 text-gray-800 font-semibold break-all"><?php echo e($laporan->nim); ?></td>
                        <td class="px-3 sm:px-6 py-3 text-gray-800"><?php echo e($laporan->name); ?></td>
                        <td class="px-3 sm:px-6 py-3 text-gray-700"><?php echo e(ucfirst($laporan->semester)); ?></td>
                        <td class="px-3 sm:px-6 py-3">
                            <span class="<?php echo e($colorClass); ?> px-3 py-1 rounded-full text-xs font-semibold">
                                <?php echo e($status); ?>

                            </span>
                        </td>
                        <td class="px-3 sm:px-6 py-3 text-center">
                            <div class="grid justify-center grid-cols-1 sm:grid-cols-2 gap-1 sm:gap-2">
                                <div class="w-full">
                                    <a href="<?php echo e(url('/admin/laporan/'.$laporan->laporan_id)); ?>"
                                        class="flex w-full bg-[#09697E] hover:bg-[#075263] text-white py-2 rounded text-xs cursor-pointer">
                                            <div class="w-full flex items-center justify-center">Edit</div>
                                    </a>
                                </div>
                                <form method="POST" action="<?php echo e(url('/admin/laporan/'.$laporan->laporan_id)); ?>"
                                      onsubmit="return confirm('Hapus data Laporan <?php echo e($laporan->laporan_id); ?>?')" class="w-full">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="w-full bg-[#000000] hover:bg-gray-800 text-white px-3 py-2 rounded text-xs cursor-pointer">
                                        Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-6 text-gray-500 italic">
                            Tidak ada data laporan mahasiswa
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="pt-4">
        <?php echo e($dataLaporan->withQueryString()->links()); ?>

    </div>
</div>
<?php /**PATH G:\Code\Web\monitoring-beasiswa-laravel\resources\views/components/tabel-laporan-admin.blade.php ENDPATH**/ ?>