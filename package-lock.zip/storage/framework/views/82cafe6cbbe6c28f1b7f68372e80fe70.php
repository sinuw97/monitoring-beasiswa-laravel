<?php $__env->startSection('content'); ?>
    <main class="block bg-white max-w-5xl mx-auto shadow-lg rounded-xl p-6 border-l-4 border-[#09697E] my-2 sm:my-8">
        
            <h2 class="font-bold text-lg mb-4">Edit Data Mahasiswa</h2>

            
            <?php if(session('success')): ?>
                <div class="bg-green-100 text-green-700 p-2 rounded mb-3">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(url('/admin/data-mahasiswa/edit/'.$dataMahasiswa->nim)); ?>" method="POST" class="flex flex-col sm:grid sm:grid-cols-2 gap-2 sm:gap-4 text-sm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div>
                    <label class="block text-gray-600">Nama</label>
                    <input type="text" class="w-full border rounded-md px-3 py-2"
                        value="<?php echo e($dataMahasiswa->name); ?>" name="name">
                </div>

                <div>
                    <label class="block text-gray-600">Email</label>
                    <input type="email" name="email" class="w-full border rounded-md px-3 py-2"
                        value="<?php echo e(old('email', $dataMahasiswa->email)); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-gray-600">NIM</label>
                    <input type="text" name="nim" class="w-full border rounded-md px-3 py-2"
                        value="<?php echo e($dataMahasiswa->nim); ?>">
                </div>

                <div>
                    <label class="block text-gray-600">Program Studi</label>
                    <input type="text" name="prodi" class="w-full border rounded-md px-3 py-2"
                        value="<?php echo e($dataMahasiswa->detailMahasiswa->prodi ?? ''); ?>">
                </div>

                <div>
                    <label class="block text-gray-600">Jenis Beasiswa</label>
                    <input type="text" name="jenis_beasiswa" class="w-full border rounded-md px-3 py-2"
                        value="<?php echo e($dataMahasiswa->detailMahasiswa->jenis_beasiswa ?? ''); ?>">
                </div>

                <div>
                    <label class="block text-gray-600">Angkatan</label>
                    <input type="text" name="angkatan" class="w-full border rounded-md px-3 py-2"
                        value="<?php echo e($dataMahasiswa->detailMahasiswa->angkatan ?? ''); ?>">
                </div>

                <div>
                    <label class="block text-gray-600">Kelas</label>
                    <input type="text" name="kelas" class="w-full border rounded-md px-3 py-2"
                        value="<?php echo e($dataMahasiswa->detailMahasiswa->kelas ?? ''); ?>">
                </div>

                <div>
                    <label class="block text-gray-600">Status</label>
                    <select name="status" class="w-full border rounded-md px-3 py-2">
                        <?php if($dataMahasiswa?->detailMahasiswa->status): ?>
                            <option value="" <?php echo e($dataMahasiswa->detailMahasiswa->status != 'Aktif' && $dataMahasiswa->detailMahasiswa->status != 'Non-Aktif' ? 'selected' : ''); ?>>
                            Pilih Keaktifan
                        </option>
                        <option value="Aktif" <?php echo e($dataMahasiswa->detailMahasiswa->status == 'Aktif' ? 'selected' : ''); ?>>
                            Aktif
                        </option>
                        <option value="Non-Aktif" <?php echo e($dataMahasiswa->detailMahasiswa->status == 'Non-Aktif' ? 'selected' : ''); ?>>
                            Non-Aktif
                        </option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="col-span-2">
                    <label class="block text-gray-600">Jenis Kelamin</label>
                    <div class="flex gap-4 mt-1">
                        <label class="flex items-center gap-2">
                            <?php if($dataMahasiswa->detailMahasiswa->jenis_kelamin): ?>
                                <input type="radio" name="jenis_kelamin"
                                <?php echo e($dataMahasiswa->detailMahasiswa->jenis_kelamin == 'Laki-Laki' ? 'checked' : ''); ?> value="Laki-Laki">
                            Laki-laki
                            <?php endif; ?>
                        </label>
                        <label class="flex items-center gap-2">
                            <?php if($dataMahasiswa->detailMahasiswa->jenis_kelamin): ?>
                            <input type="radio" name="jenis_kelamin"
                                <?php echo e($dataMahasiswa->detailMahasiswa->jenis_kelamin == 'Perempuan' ? 'checked' : ''); ?> value="Perempuan">
                            Perempuan
                            <?php endif; ?>
                        </label>
                    </div>
                </div>

                <div>
                    <label class="block text-gray-600">No HP</label>
                    <input type="text" name="no_hp" class="w-full border rounded-md px-3 py-2"
                        value="<?php echo e(old('no_hp', $dataMahasiswa->detailMahasiswa->no_hp ?? '')); ?>">
                    <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-gray-600">Alamat</label>
                    <textarea name="alamat" class="w-full border rounded-md px-3 py-2"><?php echo e(old('alamat', $dataMahasiswa->detailMahasiswa->alamat ?? '')); ?></textarea>
                    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-span-2 mt-4 flex justify-between">
                    <a href="<?php echo e(url('/admin/data-mahasiswa')); ?>"
                        class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md">Kembali</a>
                    <button type="submit"
                        class="bg-blue-600 cursor-pointer hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-md">
                        Simpan
                    </button>
                </div>
            </form>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Code\Web\monitoring-beasiswa-laravel\resources\views/admin/data-mahasiswa/edit.blade.php ENDPATH**/ ?>