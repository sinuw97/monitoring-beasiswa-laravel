<?php $__env->startSection('content'); ?>
    
    <main class="min-h-screen flex-1 p-2 sm:p-6 bg-gray-50">
        <div class="max-w-5xl mx-auto">
            
            <div class="bg-white shadow-lg rounded-xl p-6 border-l-4 border-[#E8BE00] mb-2 sm:mb-8">
                <h2 class="text-xl font-semibold text-[#09697E] mb-4">Informasi Akun</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-4">
                    <div>
                        <p class="text-gray-500">User ID</p>
                        <p class="font-bold text-[#000000]"><?php echo e($dataAdmin->user_id); ?></p>
                    </div>
                    <div>
                        <p class="text-gray-500">Nama</p>
                        <p class="font-bold text-[#000000]"><?php echo e($dataAdmin->name); ?></p>
                    </div>
                    <div>
                        <p class="text-gray-500">Email</p>
                        <p class="font-bold text-[#000000]"><?php echo e($dataAdmin->email); ?></p>
                    </div>
                    <div>
                        <p class="text-gray-500">Tanggal akun dibuat</p>
                        <p class="font-bold text-[#000000]"><?php echo e(\Carbon\Carbon::parse($dataAdmin->created_at)->format('d M Y')); ?></p>
                    </div>
                </div>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-2 sm:gap-6">
                <div class="bg-[#09697E] text-white rounded-lg p-5 flex flex-col justify-between shadow hover:scale-[1.02] transition">
                    <div>
                        <h3 class="text-lg font-semibold">Tahun Ajaran</h3>
                        <p class="text-3xl font-bold mt-2">Ganjil 2025/2026</p>
                    </div>
                </div>
                <div class="bg-[#E8BE00] text-[#000000] rounded-lg p-5 flex flex-col justify-between shadow hover:scale-[1.02] transition">
                    <div>
                        <h3 class="text-lg font-semibold">Jumlah Mahasiswa</h3>
                        <p class="text-3xl font-bold mt-2"><?php echo e($jmlMahasiswwa); ?></p>
                    </div>
                    <a href="#" class="text-sm text-[#09697E] mt-3 hover:underline">Lihat Detail</a>
                </div>
                <div class="bg-[#000000] text-white rounded-lg p-5 flex flex-col justify-between shadow hover:scale-[1.02] transition">
                    <div>
                        <h3 class="text-lg font-semibold">Jumlah Laporan Terajukan</h3>
                        <p class="text-3xl font-bold mt-2"><?php echo e($jmlLaporan); ?></p>
                    </div>
                    <a href="#" class="text-sm text-[#E8BE00] mt-3 hover:underline">Lihat Detail</a>
                </div>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="bg-fff text-black shadow-lg rounded-xl max-w-5xl mx-auto p-6 border-l-4 border-[#09697E] mt-2 sm:mt-8">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php echo $__env->make('components.tabel-periode-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Code\Web\monitoring-beasiswa-laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>