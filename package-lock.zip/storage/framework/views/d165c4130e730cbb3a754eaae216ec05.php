<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>
    <title>Riwayat Laporan Monev</title>
</head>

<body class="bg-[#F8F6F6]">
    <?php if (isset($component)) { $__componentOriginalab674573b0fa75d45d8b33fa67b4512e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab674573b0fa75d45d8b33fa67b4512e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar-mhs','data' => ['mhsAvatar' => ''.e($dataMahasiswa->avatar).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar-mhs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['mhsAvatar' => ''.e($dataMahasiswa->avatar).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab674573b0fa75d45d8b33fa67b4512e)): ?>
<?php $attributes = $__attributesOriginalab674573b0fa75d45d8b33fa67b4512e; ?>
<?php unset($__attributesOriginalab674573b0fa75d45d8b33fa67b4512e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab674573b0fa75d45d8b33fa67b4512e)): ?>
<?php $component = $__componentOriginalab674573b0fa75d45d8b33fa67b4512e; ?>
<?php unset($__componentOriginalab674573b0fa75d45d8b33fa67b4512e); ?>
<?php endif; ?>

    <section class="flex justify-center w-full h-auto">
        <div class="bg-[#fdfdfd] w-[1100px] h-auto p-6">
            <h2 class="text-xl font-bold ml-3 mb-2">Detail Laporan Monev</h2>
            <div class="h-auto bg-blue-200 ml-3 mr-3 px-3 py-3 rounded mb-3">
                <p>Nama : <?php echo e($dataMahasiswa->name); ?></p>
                <p>NIM : <?php echo e($dataMahasiswa->nim); ?></p>
                <p>Periode : <?php echo e($laporan->periodeSemester?->tahun_akademik); ?> <?php echo e($laporan->periodeSemester?->semester); ?>

                </p>
                <p>Dibuat : <?php echo e($laporan->created_at->translatedFormat('d F Y')); ?></p>
                <p>Status : <?php echo e($laporan->status); ?></p>
            </div>

            <?php if(session('success')): ?>
                <div class="bg-green-100 mx-3 w-auto px-3 py-3 rounded mb-3">
                    <?php echo e(session('success')); ?>

                </div>
            <?php elseif(session('error')): ?>
                <div class="bg-red-200 w-auto mx-3 px-3 py-3 rounded mb-3">
                    <?php echo e(session('fails')); ?>

                </div>
            <?php endif; ?>

            <div class="">
                
                <div x-cloak x-data="{ openReports: false, openEditReports: false, editDataReports: {} }" class="mb-3 mt-5 pr-3 cursor-default"
                    x-on:edit-reports.window="editDataReports = $event.detail; openEditReports = true">
                    <h2 class="text-xl font-bold text-[#013F4E] ml-3">A. KEGIATAN AKADEMIK</h2>
                    <p class="text-[#013F4E] text-[14pt] font-semibold mb-0.5 ml-3">Nilai IPS dan IPK Semester Ini
                    </p>

                    <div class="overflow-x-auto">
                        
                        <?php if (isset($component)) { $__componentOriginal8640d5203a2e31c36b732a5eb2389997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8640d5203a2e31c36b732a5eb2389997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabel','data' => ['headers' => ['No', 'Semester', 'IPS', 'IPK', 'Bukti', 'Komentar', 'Status'],'columns' => ['semester', 'ips', 'ipk', 'bukti', 'komentar', 'status'],'rows' => $parsingAcademicReports,'idKey' => 'id','editEvent' => 'edit-reports','deleteRoute' => 'laporan.academic-reports.delete','status' => $laporan->status,'style' => 'riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['No', 'Semester', 'IPS', 'IPK', 'Bukti', 'Komentar', 'Status']),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['semester', 'ips', 'ipk', 'bukti', 'komentar', 'status']),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parsingAcademicReports),'idKey' => 'id','editEvent' => 'edit-reports','deleteRoute' => 'laporan.academic-reports.delete','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->status),'style' => 'riwayat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $attributes = $__attributesOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $component = $__componentOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__componentOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div x-cloak x-data="{ openAcademic: false, openEditAcademic: false, editDataAcademy: {} }" class="mb-2 pr-3 cursor-default"
                    x-on:edit-academic.window="editDataAcademy = $event.detail; openEditAcademic = true">
                    <p class="text-[#013F4E] text-[14pt] font-semibold mb-0.5 ml-3">Kegiatan Akademik</p>

                    <div class="overflow-x-auto">
                        <?php if (isset($component)) { $__componentOriginal8640d5203a2e31c36b732a5eb2389997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8640d5203a2e31c36b732a5eb2389997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabel','data' => ['headers' => [
                            'No',
                            'Nama Kegiatan',
                            'Tipe Kegiatan',
                            'Keikutsertaan',
                            'Tempat',
                            'Tanggal Mulai',
                            'Tanggal Selesai',
                            'Bukti',
                            'Point',
                            'Komentar',
                            'Status',
                        ],'columns' => [
                            'activity-name',
                            'activity-type',
                            'participation',
                            'place',
                            'start-date',
                            'end-date',
                            'bukti',
                            'point',
                            'komentar',
                            'status',
                        ],'rows' => $parsingAcademicActivities,'idKey' => 'id','editEvent' => 'edit-academic','deleteRoute' => 'laporan.academic-activities.delete','status' => $laporan->status,'style' => 'riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'No',
                            'Nama Kegiatan',
                            'Tipe Kegiatan',
                            'Keikutsertaan',
                            'Tempat',
                            'Tanggal Mulai',
                            'Tanggal Selesai',
                            'Bukti',
                            'Point',
                            'Komentar',
                            'Status',
                        ]),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'activity-name',
                            'activity-type',
                            'participation',
                            'place',
                            'start-date',
                            'end-date',
                            'bukti',
                            'point',
                            'komentar',
                            'status',
                        ]),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parsingAcademicActivities),'idKey' => 'id','editEvent' => 'edit-academic','deleteRoute' => 'laporan.academic-activities.delete','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->status),'style' => 'riwayat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $attributes = $__attributesOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $component = $__componentOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__componentOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div x-cloak x-data="{ openOrganization: false, openEditOrg: false, editDataOrg: {} }" class="mb-2 pr-3 cursor-default"
                    x-on:edit-org.window="editDataOrg = $event.detail; openEditOrg = true">
                    <h2 class="text-xl font-bold text-[#013F4E] ml-3 mt-4">B. KEGIATAN NON-AKADEMIK</h2>
                    <p class="text-[#013F4E] text-[14pt] font-semibold mb-0.5 ml-3">Kegiatan Organisasi Mahasiswa</p>

                    <div class="overflow-x-auto">
                        <?php if (isset($component)) { $__componentOriginal8640d5203a2e31c36b732a5eb2389997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8640d5203a2e31c36b732a5eb2389997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabel','data' => ['headers' => [
                            'No',
                            'Nama UKM',
                            'Nama Kegiatan',
                            'Tingkat',
                            'Posisi',
                            'Tempat',
                            'Tanggal Mulai',
                            'Tanggal Selesai',
                            'Bukti',
                            'Point',
                            'Komentar',
                            'Status',
                        ],'columns' => [
                            'ukm-name',
                            'activity-name',
                            'level',
                            'position',
                            'place',
                            'start-date',
                            'end-date',
                            'bukti',
                            'point',
                            'komentar',
                            'status',
                        ],'rows' => $parsingOrganizationActivities,'idKey' => 'id','editEvent' => 'edit-org','deleteRoute' => 'laporan.org-activities.delete','status' => $laporan->status,'style' => 'riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'No',
                            'Nama UKM',
                            'Nama Kegiatan',
                            'Tingkat',
                            'Posisi',
                            'Tempat',
                            'Tanggal Mulai',
                            'Tanggal Selesai',
                            'Bukti',
                            'Point',
                            'Komentar',
                            'Status',
                        ]),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'ukm-name',
                            'activity-name',
                            'level',
                            'position',
                            'place',
                            'start-date',
                            'end-date',
                            'bukti',
                            'point',
                            'komentar',
                            'status',
                        ]),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parsingOrganizationActivities),'idKey' => 'id','editEvent' => 'edit-org','deleteRoute' => 'laporan.org-activities.delete','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->status),'style' => 'riwayat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $attributes = $__attributesOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $component = $__componentOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__componentOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div x-cloak x-data="{ openCommittee: false, openEditCommittee: false, editDataCommittee: {} }" class="mb-2 pr-3 cursor-default"
                    x-on:edit-committee.window="editDataCommittee = $event.detail; openEditCommittee = true">
                    <p class="text-[#013F4E] text-[14pt] font-semibold ml-3 mb-0.5">Kegiatan Kepanitiaan Atau Penugasan
                    </p>

                    <div class="overflow-x-auto">
                        <?php if (isset($component)) { $__componentOriginal8640d5203a2e31c36b732a5eb2389997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8640d5203a2e31c36b732a5eb2389997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabel','data' => ['headers' => [
                            'No',
                            'Nama Kegiatan',
                            'Tipe Kegiatan',
                            'Keikutsertaan',
                            'Tingkat',
                            'Tempat',
                            'Tanggal Mulai',
                            'Tanggal Selesai',
                            'Bukti',
                            'Point',
                            'Komentar',
                            'Status',
                        ],'columns' => [
                            'activity-name',
                            'activity-type',
                            'participation',
                            'level',
                            'place',
                            'start-date',
                            'end-date',
                            'bukti',
                            'point',
                            'komentar',
                            'status',
                        ],'rows' => $parsingCommitteeActivities,'idKey' => 'id','editEvent' => 'edit-committee','deleteRoute' => 'laporan.committee-activities.hapus','status' => $laporan->status,'style' => 'riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'No',
                            'Nama Kegiatan',
                            'Tipe Kegiatan',
                            'Keikutsertaan',
                            'Tingkat',
                            'Tempat',
                            'Tanggal Mulai',
                            'Tanggal Selesai',
                            'Bukti',
                            'Point',
                            'Komentar',
                            'Status',
                        ]),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'activity-name',
                            'activity-type',
                            'participation',
                            'level',
                            'place',
                            'start-date',
                            'end-date',
                            'bukti',
                            'point',
                            'komentar',
                            'status',
                        ]),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parsingCommitteeActivities),'idKey' => 'id','editEvent' => 'edit-committee','deleteRoute' => 'laporan.committee-activities.hapus','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->status),'style' => 'riwayat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $attributes = $__attributesOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $component = $__componentOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__componentOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div x-cloak x-data="{ openAchievement: false, openEditAchievement: false, editDataAchievement: {} }" class="mb-2 pr-3 cursor-default"
                    x-on:edit-achievement.window="editDataAchievement = $event.detail; openEditAchievement = true">
                    <p class="text-[#013F4E] text-[14pt] font-semibold ml-3 mb-0.5">Prestasi Mahasiswa</p>

                    <div class="overflow-x-auto">
                        <?php if (isset($component)) { $__componentOriginal8640d5203a2e31c36b732a5eb2389997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8640d5203a2e31c36b732a5eb2389997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabel','data' => ['headers' => [
                            'No',
                            'Nama Prestasi',
                            'Tipe Prestasi',
                            'Tingkat',
                            'Juara',
                            'Tempat',
                            'Tanggal Mulai',
                            'Tanggal Selesai',
                            'Bukti',
                            'Point',
                            'Komentar',
                            'Status',
                        ],'columns' => [
                            'achievements-name',
                            'achievements-type',
                            'level',
                            'award',
                            'place',
                            'start-date',
                            'end-date',
                            'bukti',
                            'point',
                            'komentar',
                            'status',
                        ],'rows' => $parsingAchievements,'idKey' => 'id','editEvent' => 'edit-achievement','deleteRoute' => 'laporan.achievements.hapus','status' => $laporan->status,'style' => 'riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'No',
                            'Nama Prestasi',
                            'Tipe Prestasi',
                            'Tingkat',
                            'Juara',
                            'Tempat',
                            'Tanggal Mulai',
                            'Tanggal Selesai',
                            'Bukti',
                            'Point',
                            'Komentar',
                            'Status',
                        ]),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'achievements-name',
                            'achievements-type',
                            'level',
                            'award',
                            'place',
                            'start-date',
                            'end-date',
                            'bukti',
                            'point',
                            'komentar',
                            'status',
                        ]),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parsingAchievements),'idKey' => 'id','editEvent' => 'edit-achievement','deleteRoute' => 'laporan.achievements.hapus','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->status),'style' => 'riwayat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $attributes = $__attributesOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $component = $__componentOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__componentOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div x-cloak x-data="{ openIndependent: false, openEditIndependent: false, editDataIndependent: {} }" class="mb-2 pr-3 cursor-default"
                    x-on:edit-independent="editDataIndependent = $event.detail; openEditIndependent = true">
                    <p class="text-[#013F4E] text-[14pt] font-semibold ml-3 mb-0.5">Kegiatan Mandiri Mahasiswa Selama
                        Satu
                        Semester</p>

                    <div class="overflow-x-auto">
                        <?php if (isset($component)) { $__componentOriginal8640d5203a2e31c36b732a5eb2389997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8640d5203a2e31c36b732a5eb2389997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabel','data' => ['headers' => [
                            'No',
                            'Nama Kegiatan',
                            'Tipe Kegiatan',
                            'Keikutsertaan',
                            'Tempat',
                            'Tanggal Mulai',
                            'Tanggal Selesai',
                            'Bukti',
                            'Point',
                            'Komentar',
                            'Status',
                        ],'columns' => [
                            'activity-name',
                            'activity-type',
                            'participation',
                            'place',
                            'start-date',
                            'end-date',
                            'bukti',
                            'point',
                            'komentar',
                            'status',
                        ],'rows' => $parsingIndependentActivities,'idKey' => 'id','editEvent' => 'edit-independent','deleteRoute' => 'laporan.independent-activities.hapus','status' => $laporan->status,'style' => 'riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'No',
                            'Nama Kegiatan',
                            'Tipe Kegiatan',
                            'Keikutsertaan',
                            'Tempat',
                            'Tanggal Mulai',
                            'Tanggal Selesai',
                            'Bukti',
                            'Point',
                            'Komentar',
                            'Status',
                        ]),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'activity-name',
                            'activity-type',
                            'participation',
                            'place',
                            'start-date',
                            'end-date',
                            'bukti',
                            'point',
                            'komentar',
                            'status',
                        ]),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parsingIndependentActivities),'idKey' => 'id','editEvent' => 'edit-independent','deleteRoute' => 'laporan.independent-activities.hapus','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->status),'style' => 'riwayat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $attributes = $__attributesOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $component = $__componentOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__componentOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div x-cloak x-data="{ openEvaluation: false, openEditEvaluation: false, editDataEvaluation: {} }" class="pl-3 mb-2 mt-4 cursor-default">
                    <h2 class="text-xl font-bold text-[#013F4E]">C. EVALUASI</h2>
                    
                    <div>
                        <p class="text-[#013F4E] text-[14pt] font-semibold mb-0.5">Faktor Pendukung</p>
                        <textarea name="faktor-pendukung" id="faktor-pendukung"
                            class="resize-none px-2 py-0.5 w-[450px] h-[200px] cursor-default shadow-md border border-[#c0c0c0] focus:outline-none focus:ring-0"
                            readonly><?php echo e($parsingEvaluations->support_factors ?? '-'); ?></textarea>
                    </div>
                    <div>
                        <p class="text-[#013F4E] text-[14pt] font-semibold mb-0.5">Faktor Penghambat</p>
                        <textarea name="faktor-pendukung" id=""
                            class="resize-none px-2 py-0.5 w-[450px] h-[200px] cursor-default shadow-md border border-[#c0c0c0] focus:outline-none focus:ring-0"
                            readonly><?php echo e($parsingEvaluations->barrier_factors ?? '-'); ?></textarea>
                    </div>
                </div>

                
                <div x-cloak x-data="{ openTargetRep: false, openEditTargetRep: false, editDataTargetRep: {} }" class="mb-2 mt-2 pr-3 cursor-default"
                    x-on:edit-target-rep.window="editDataTargetRep = $event.detail; openEditTargetRep = true">
                    <h2 class="text-xl font-bold text-[#013F4E] mt-4 ml-3">D. TARGET SEMESTER DEPAN</h2>
                    <p class="text-[#013F4E] text-[14pt] font-semibold ml-3 mb-0.5">Rencana Nilai IPS dan IPK
                        Semester
                        Depan
                    </p>

                    <div class="overflow-x-auto">
                        <?php if (isset($component)) { $__componentOriginal8640d5203a2e31c36b732a5eb2389997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8640d5203a2e31c36b732a5eb2389997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabel','data' => ['headers' => ['No', 'Semester', 'Target IPS', 'Target IPK', 'Status'],'columns' => ['semester', 'target-ips', 'target-ipk', 'status'],'rows' => $parsingNextReports,'idKey' => 'id','editEvent' => 'edit-target-rep','deleteRoute' => 'laporan.next-semester-reports.hapus','status' => $laporan->status,'style' => 'riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['No', 'Semester', 'Target IPS', 'Target IPK', 'Status']),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['semester', 'target-ips', 'target-ipk', 'status']),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parsingNextReports),'idKey' => 'id','editEvent' => 'edit-target-rep','deleteRoute' => 'laporan.next-semester-reports.hapus','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->status),'style' => 'riwayat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $attributes = $__attributesOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $component = $__componentOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__componentOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div x-cloak x-data="{ openTargetAcademic: false, openEditTargetAcademic: false, editDataTargetAcademic: {} }" class="mb-2 pr-3 cursor-default"
                    x-on:edit-target-academic.window="editDataTargetAcademic = $event.detail; openEditTargetAcademic = true">
                    <p class="text-[#013F4E] text-[14pt] font-semibold ml-3 mb-0.5">Rencana Kegiatan Akademik
                        Semester
                        Depan
                    </p>

                    <div class="overflow-x-auto">
                        <?php if (isset($component)) { $__componentOriginal8640d5203a2e31c36b732a5eb2389997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8640d5203a2e31c36b732a5eb2389997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabel','data' => ['headers' => ['No', 'Nama Kegiatan', 'Rencana/Strategi', 'Status'],'columns' => ['activity-name', 'strategy', 'status'],'rows' => $parsingNextAcademicActivities,'idKey' => 'id','editEvent' => 'edit-target-academic','deleteRoute' => 'laporan.next-smt-activities.hapus','status' => $laporan->status,'style' => 'riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['No', 'Nama Kegiatan', 'Rencana/Strategi', 'Status']),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['activity-name', 'strategy', 'status']),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parsingNextAcademicActivities),'idKey' => 'id','editEvent' => 'edit-target-academic','deleteRoute' => 'laporan.next-smt-activities.hapus','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->status),'style' => 'riwayat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $attributes = $__attributesOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $component = $__componentOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__componentOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div x-cloak x-data="{ openTargetAchievement: false, openEditTargetAchievement: false, editDatatargetAchievement: {} }" class="mb-2 pr-3 cursor-default"
                    x-on:edit-target-achievement="editDatatargetAchievement = $event.detail; openEditTargetAchievement = true">
                    <p class="text-[#013F4E] text-[14pt] font-semibold ml-3 mb-0.5">Rencana Prestasi</p>

                    <div class="overflow-x-auto">
                        <?php if (isset($component)) { $__componentOriginal8640d5203a2e31c36b732a5eb2389997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8640d5203a2e31c36b732a5eb2389997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabel','data' => ['headers' => ['No', 'Nama Prestasi', 'Tingkat', 'Raihan', 'Status'],'columns' => ['achievements-name', 'level', 'award', 'status'],'rows' => $parsingNextAchievements,'idKey' => 'id','editEvent' => 'edit-target-achievement','deleteRoute' => 'laporan.next-smt-achievements.hapus','status' => $laporan->status,'style' => 'riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['No', 'Nama Prestasi', 'Tingkat', 'Raihan', 'Status']),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['achievements-name', 'level', 'award', 'status']),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parsingNextAchievements),'idKey' => 'id','editEvent' => 'edit-target-achievement','deleteRoute' => 'laporan.next-smt-achievements.hapus','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->status),'style' => 'riwayat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $attributes = $__attributesOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $component = $__componentOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__componentOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div x-cloak x-data="{ openTargetIndependent: false, openEditTargetIndependent: false, editDataTargetIndependent: {} }" class="mb-2 pr-3 cursor-default"
                    x-on:edit-target-independent="editDataTargetIndependent = $event.detail; openEditTargetIndependent = true">
                    <p class="text-[#013F4E] text-[14pt] font-semibold ml-3 mb-0.5">Rencana Kegiatan Mandiri</p>

                    <div class="overflow-x-auto">
                        <?php if (isset($component)) { $__componentOriginal8640d5203a2e31c36b732a5eb2389997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8640d5203a2e31c36b732a5eb2389997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabel','data' => ['headers' => ['No', 'Nama Kegiatan', 'Rencana/Strategi', 'Keikutsertaan', 'Status'],'columns' => ['activity-name', 'strategy', 'participation', 'status'],'rows' => $parsingNextIndependentActivities,'idKey' => 'id','editEvent' => 'edit-target-independent','deleteRoute' => 'laporan.next-smt-independent.hapus','status' => $laporan->status,'style' => 'riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['No', 'Nama Kegiatan', 'Rencana/Strategi', 'Keikutsertaan', 'Status']),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['activity-name', 'strategy', 'participation', 'status']),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parsingNextIndependentActivities),'idKey' => 'id','editEvent' => 'edit-target-independent','deleteRoute' => 'laporan.next-smt-independent.hapus','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->status),'style' => 'riwayat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $attributes = $__attributesOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__attributesOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8640d5203a2e31c36b732a5eb2389997)): ?>
<?php $component = $__componentOriginal8640d5203a2e31c36b732a5eb2389997; ?>
<?php unset($__componentOriginal8640d5203a2e31c36b732a5eb2389997); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div class="mt-4 flex gap-2">
                <button type="button" class="button bg-[#E8BE00] px-2 py-1 rounded-md cursor-pointer">
                    <a href="<?php echo e(route('mahasiswa.dashboard')); ?>">Kembali</a>
                </button>
            </div>
        </div>
    </section>
</body>

</html>
<?php /**PATH G:\Code\Web\monitoring-beasiswa-laravel\resources\views\mahasiswa\detail-laporan.blade.php ENDPATH**/ ?>