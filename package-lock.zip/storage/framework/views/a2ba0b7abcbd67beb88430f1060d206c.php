<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil Mahasiswa</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-100">
    <div class="flex flex-col min-h-screen">
        
        <?php if (isset($component)) { $__componentOriginalab674573b0fa75d45d8b33fa67b4512e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab674573b0fa75d45d8b33fa67b4512e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar-mhs','data' => ['mhsName' => ''.e($dataMahasiswa->name).'','mhsAvatar' => ''.e($dataMahasiswa->avatar).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar-mhs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['mhsName' => ''.e($dataMahasiswa->name).'','mhsAvatar' => ''.e($dataMahasiswa->avatar).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab674573b0fa75d45d8b33fa67b4512e)): ?>
<?php $attributes = $__attributesOriginalab674573b0fa75d45d8b33fa67b4512e; ?>
<?php unset($__attributesOriginalab674573b0fa75d45d8b33fa67b4512e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab674573b0fa75d45d8b33fa67b4512e)): ?>
<?php $component = $__componentOriginalab674573b0fa75d45d8b33fa67b4512e; ?>
<?php unset($__componentOriginalab674573b0fa75d45d8b33fa67b4512e); ?>
<?php endif; ?>

        
        <main class="flex flex-1 px-10 py-6 gap-6">
            
            <aside class="w-1/4 bg-white shadow rounded-md p-6">
                <div class="flex flex-col items-center text-center mb-6">
                    <div
                        class="flex items-center justify-center w-20 h-20 bg-gray-300 rounded-full text-xl font-bold text-white">
                        <?php echo e(strtoupper(substr($dataMahasiswa->name,0,2))); ?>

                    </div>
                    <h2 class="mt-3 font-semibold"><?php echo e($dataMahasiswa->name); ?></h2>
                </div>
                <div class="text-sm text-gray-700">
                    <p class="font-bold"><?php echo e($dataMahasiswa->nim); ?></p>
                    <p><?php echo e($dataMahasiswa->detailMahasiswa->prodi); ?></p>
                    <p>Angkatan <?php echo e($dataMahasiswa->detailMahasiswa->angkatan); ?></p>
                    <p>Beasiswa : <?php echo e($dataMahasiswa->detailMahasiswa->jenis_beasiswa); ?></p>
                    <p>Kelas : <?php echo e($dataMahasiswa->detailMahasiswa->kelas); ?></p>
                    <p>Jenis Kelamin : <?php echo e($dataMahasiswa->detailMahasiswa->jenis_kelamin); ?></p>
                </div>

                <div class="mt-6">
                    <p class="text-sm font-semibold mb-2">Laporan terajukan</p>
                    <div class="w-full bg-gray-200 rounded-full h-2.5">
                        <div class="bg-blue-500 h-2.5 rounded-full" style="width: 12.5%"></div>
                    </div>
                    <p class="text-xs mt-1">1/8</p>
                </div>
            </aside>

            
            <section class="flex-1 bg-white shadow rounded-md p-6">
                <h2 class="font-bold text-lg mb-4">Edit Data Mahasiswa</h2>

                
                <?php if(session('success')): ?>
                    <div class="bg-green-100 text-green-700 p-2 rounded mb-3">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('mahasiswa.profile.update')); ?>" method="POST" class="grid grid-cols-2 gap-4 text-sm">
                    <?php echo csrf_field(); ?>

                    <div>
                        <label class="block text-gray-600">Nama</label>
                        <input type="text" class="w-full border rounded-md px-3 py-2 bg-gray-100"
                            value="<?php echo e($dataMahasiswa->name); ?>" disabled>
                    </div>

                    <div>
                        <label class="block text-gray-600">Email</label>
                        <input type="email" name="email" class="w-full border rounded-md px-3 py-2"
                            value="<?php echo e(old('email', $dataMahasiswa->email)); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-gray-600">NIM</label>
                        <input type="text" class="w-full border rounded-md px-3 py-2 bg-gray-100"
                            value="<?php echo e($dataMahasiswa->nim); ?>" disabled>
                    </div>

                    <div>
                        <label class="block text-gray-600">Program Studi</label>
                        <input type="text" class="w-full border rounded-md px-3 py-2 bg-gray-100"
                            value="<?php echo e($dataMahasiswa->detailMahasiswa->prodi); ?>" disabled>
                    </div>

                    <div>
                        <label class="block text-gray-600">Jenis Beasiswa</label>
                        <input type="text" class="w-full border rounded-md px-3 py-2 bg-gray-100"
                            value="<?php echo e($dataMahasiswa->detailMahasiswa->jenis_beasiswa); ?>" disabled>
                    </div>

                    <div>
                        <label class="block text-gray-600">Angkatan</label>
                        <input type="text" class="w-full border rounded-md px-3 py-2 bg-gray-100"
                            value="<?php echo e($dataMahasiswa->detailMahasiswa->angkatan); ?>" disabled>
                    </div>

                    <div>
                        <label class="block text-gray-600">Kelas</label>
                        <input type="text" class="w-full border rounded-md px-3 py-2 bg-gray-100"
                            value="<?php echo e($dataMahasiswa->detailMahasiswa->kelas); ?>" disabled>
                    </div>

                    <div class="col-span-2">
                        <label class="block text-gray-600">Jenis Kelamin</label>
                        <div class="flex gap-4 mt-1">
                            <label class="flex items-center gap-2">
                                <input type="radio" disabled
                                    <?php echo e($dataMahasiswa->detailMahasiswa->jenis_kelamin == 'Laki-laki' ? 'checked' : ''); ?>>
                                Laki-laki
                            </label>
                            <label class="flex items-center gap-2">
                                <input type="radio" disabled
                                    <?php echo e($dataMahasiswa->detailMahasiswa->jenis_kelamin == 'Perempuan' ? 'checked' : ''); ?>>
                                Perempuan
                            </label>
                        </div>
                    </div>

                    <div>
                        <label class="block text-gray-600">No HP</label>
                        <input type="text" name="no_hp" class="w-full border rounded-md px-3 py-2"
                            value="<?php echo e(old('no_hp', $dataMahasiswa->detailMahasiswa->no_hp ?? '')); ?>">
                        <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-gray-600">Alamat</label>
                        <textarea name="alamat" class="w-full border rounded-md px-3 py-2"><?php echo e(old('alamat', $dataMahasiswa->detailMahasiswa->alamat ?? '')); ?></textarea>
                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-600"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-span-2 mt-4 flex justify-between">
                        <a href="<?php echo e(route('mahasiswa.profile')); ?>"
                            class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md">Batal</a>
                        <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-md">
                            Simpan
                        </button>
                    </div>
                </form>
            </section>
        </main>
    </div>
</body>

</html>
<?php /**PATH G:\Code\Web\monitoring-beasiswa-laravel\resources\views\mahasiswa\edit-profile.blade.php ENDPATH**/ ?>