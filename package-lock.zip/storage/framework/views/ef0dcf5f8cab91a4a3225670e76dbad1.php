<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'headers' => [], // Untuk nama headers pd tiap tabel ["No", "semester", 'ips', ...]
    'columns' => [], // Untuk nama kolomnya ['semester', 'ips', ...]
    'rows' => [], // collection atau array of arrays/objects
    'idKey' => 'id', // nama key untuk id tiap row
    'editEvent' => 'edit-row', // default
    'deleteRoute' => '', // default value
    'status' => 'Draft',
    'style' => ''
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'headers' => [], // Untuk nama headers pd tiap tabel ["No", "semester", 'ips', ...]
    'columns' => [], // Untuk nama kolomnya ['semester', 'ips', ...]
    'rows' => [], // collection atau array of arrays/objects
    'idKey' => 'id', // nama key untuk id tiap row
    'editEvent' => 'edit-row', // default
    'deleteRoute' => '', // default value
    'status' => 'Draft',
    'style' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<table class="min-w-full text-sm shadow-lg bg-white border-separate border-spacing-0 m-4">
    <thead>
        <?php if($style === 'riwayat'): ?>
        <tr class="bg-[#09697E]">
            <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th class="px-4 py-2 text-center text-white"><?php echo e($header); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php elseif($style === 'draft'): ?>
        <tr class="bg-[#E8BE00]">
            <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th class="px-4 py-2 text-center"><?php echo e($header); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($status === 'Draft'): ?>
                <th class="px-4 py-2 text-center">Aksi</th>
            <?php endif; ?>
        </tr>
        <?php endif; ?>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = ($rows ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="bg-[#f8f8f8]">
                <td class="px-4 py-2 text-center"><?php echo e($loop->iteration); ?></td>
                <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td class="px-4 py-2 text-center">
                        <?php
                            $value = data_get($row, $col);
                        ?>

                        <?php if($col === 'bukti' && $value && $value !== 'Tidak Ada'): ?>
                            <a href="<?php echo e($value); ?>" target="_blank" class="text-blue-600 underline">
                                Lihat Bukti
                            </a>
                        <?php elseif($col === 'status' && $value && $value === 'Draft'): ?>
                            <span class="bg-[#cecece] px-2 py-1 rounded-xl">
                                <?php echo e($value); ?>

                            </span>
                        <?php elseif($col === 'status' && $value && $value === 'Pending'): ?>
                            <span class="bg-[#ffdd44] px-2 py-1 rounded-xl">
                                <?php echo e($value); ?>

                            </span>
                        <?php elseif($col === 'status' && $value && $value === 'Valid'): ?>
                            <span class="bg-[#44c96a] px-2 py-1 rounded-xl text-[#fbfbfb]">
                                <?php echo e($value); ?>

                            </span>
                        <?php elseif($col === 'status' && $value && $value === 'Rejected'): ?>
                            <span class="bg-[#e73424] px-2 py-1 rounded-xl">
                                <?php echo e($value); ?>

                            </span>
                        <?php else: ?>
                            <?php echo e($value ?? '-'); ?>

                        <?php endif; ?>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($status === 'Draft'): ?>
                    
                    <td class="px-4 py-2">
                        <div class="flex justify-center items-center gap-3">
                            <button type="button" class="flex justify-center items-center gap-2 cursor-pointer px-3 py-0.5 text-white bg-[#2179ca] hover:bg-[#1c6bb4] rounded-sm"
                                if @click="$dispatch('<?php echo e($editEvent); ?>', <?php echo e(json_encode($row)); ?>)">
                                <img src="/icon/edit.png" alt="edit-icon" class="w-[15px] h-[15px]"> Edit
                            </button>

                            <button type="button" class="flex justify-center items-center gap-2 cursor-pointer px-3 py-0.5 bg-red-500 hover:bg-red-600 text-white rounded-sm"
                                @click="$dispatch('<?php echo e('delete-row'); ?>', {
                                id: '<?php echo e(data_get($row, $idKey)); ?>',
                                route: '<?php echo e(route($deleteRoute, data_get($row, $idKey))); ?>'})">
                                <img src="/icon/delete.png" alt="edit-icon" class="w-[15px] h-[15px]"> Hapus
                            </button>
                        </div>
                    </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="<?php echo e(count($headers) + 1); ?>" class="px-4 py-4 text-center">
                    Tidak ada data
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php /**PATH G:\Code\Web\monitoring-beasiswa-laravel\resources\views\components\tabel.blade.php ENDPATH**/ ?>