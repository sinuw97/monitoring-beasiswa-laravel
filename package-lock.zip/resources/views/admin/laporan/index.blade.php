@extends('admin.layout')

@section('content')
    @include('components.tabel-laporan-admin')
@endsection
